-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Usuario` (
  `email` VARCHAR(100) NOT NULL,
  `senha` VARCHAR(45) NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `aniversario` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`email`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Perfil`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Perfil` (
  `cdo_perfil` INT NOT NULL,
  `nome_perfil` VARCHAR(45) NOT NULL,
  `Usuario_e-mail` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`cdo_perfil`, `Usuario_e-mail`),
  INDEX `fk_Perfil_Usuario1_idx` (`Usuario_e-mail` ASC) VISIBLE,
  CONSTRAINT `fk_Perfil_Usuario1`
    FOREIGN KEY (`Usuario_e-mail`)
    REFERENCES `mydb`.`Usuario` (`email`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Filmes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Filmes` (
  `cod_filme` INT NOT NULL,
  `nome_filme` VARCHAR(45) NOT NULL,
  `assistido` TINYINT NOT NULL,
  `Filmes_para_assistir_cod_lista_filmes_ver` INT NOT NULL,
  `Perfil_cdo_perfil` INT NOT NULL,
  `Perfil_Usuario_e-mail` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`cod_filme`, `Filmes_para_assistir_cod_lista_filmes_ver`, `Perfil_cdo_perfil`, `Perfil_Usuario_e-mail`),
  INDEX `fk_Filmes_Perfil1_idx` (`Perfil_cdo_perfil` ASC, `Perfil_Usuario_e-mail` ASC) VISIBLE,
  CONSTRAINT `fk_Filmes_Perfil1`
    FOREIGN KEY (`Perfil_cdo_perfil` , `Perfil_Usuario_e-mail`)
    REFERENCES `mydb`.`Perfil` (`cdo_perfil` , `Usuario_e-mail`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

select *from Usuario;