/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author jgjcp
 */
public class Banco_de_dados {
        // Objeto de COnexÃ£o com BD
    public Connection conn;
    // Objeto de Consulta SQL
    public Statement stmt;
    // Objeto com dados SQL
    private ResultSet res;  
    /**
     * Função que conecta no Banco de dados Postgree SQL 
     */
    public void conexao(){
       try
       {
        //Class.forName("com.mysql.jdbc.Driver");//com.mysql.jdbc.Driver
        conn = DriverManager.getConnection("jdbc:mysql://localhost/mydb?useTimezone=true&serverTimezone=UTC", "root", "123456");
        //root é o usuario padrão do mysql, e pode ser alterado, o mesmo vale para a senha que é 123456
    
        System.out.println("Conectado ao MYSQL.");        
        }catch(Exception e){
            System.out.println("Falha ao tentar a conexao");
            e.printStackTrace();
        }       
       try{
           stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);      
       }catch(Exception e){
           System.out.println("Falha no Cursor de ExecuÃ§Ã£o");
           e.printStackTrace();
       }
    }
    
     public Connection getConnection(){
        return conn;
    }
    
    public Statement getStatement(){
        return stmt;
    }
    /**
     * Função que desconecta do Banco de dados Postgree Sql
     */
    public void desconecta(){
        if(conn != null){
            try{
                conn.close();
            }catch(SQLException erro){
                erro.printStackTrace();
            }
            
        }
    }
}
