package Controle;

import java.sql.ResultSet;
import Modelo.Usuario_Modelo;
import java.sql.SQLException;

public class Usuario_Controle {
    Banco_de_dados bd = new Banco_de_dados();
    Banco_de_dados base =  new Banco_de_dados();
    ResultSet consulta;
    
    public void criar_usuario (Usuario_Modelo usu){
        try {
            base.conexao();
            String sql = "insert into Usuario values('"+usu.getEmail()+
                    "','"+usu.getSenha()+"','"+usu.getNome()+"','"+usu.getAniversario()+"')";
            base.getStatement().execute(sql);
            base.desconecta();
                    
        } catch (Exception erro) {
            erro.printStackTrace();
            javax.swing.JOptionPane aviso = new javax.swing.JOptionPane();
            aviso.showMessageDialog(null, "ERRO");
        }
    }
    
    public void Procurar_email(String email/*, String senha*/){
        
        try {
            bd.conexao();
            ResultSet rs = null;
            String sql = "select *from Usuario where email='"+email+"'";
            consulta = bd.getStatement().executeQuery(sql); 
        } catch (SQLException erro) {
            erro.getMessage();
             javax.swing.JOptionPane aviso = new javax.swing.JOptionPane();
             aviso.showMessageDialog(null, "ERRO");
        }
        
    }
}
