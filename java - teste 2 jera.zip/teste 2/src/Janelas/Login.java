package Janelas;

import Controle.Usuario_Controle;
import Controle.Banco_de_dados;
import Modelo.Usuario_Modelo;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Campo_email1 = new javax.swing.JTextField();
        Campo_senha1 = new javax.swing.JPasswordField();
        botao_login = new javax.swing.JButton();
        botao_limpar1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        Campo_nome2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Campo_senha2 = new javax.swing.JTextField();
        Campo_email2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        botao_registro = new javax.swing.JButton();
        botao_limpar2 = new javax.swing.JButton();
        Campo_aniversario2 = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setToolTipText("Tela Inicial");
        jTabbedPane1.setName(""); // NOI18N

        jLabel1.setText("E-mail:");

        jLabel2.setText("Senha:");

        botao_login.setText("Login");
        botao_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botao_loginActionPerformed(evt);
            }
        });

        botao_limpar1.setText("Limpar");
        botao_limpar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botao_limpar1MouseClicked(evt);
            }
        });
        botao_limpar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botao_limpar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campo_email1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campo_senha1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 245, Short.MAX_VALUE)
                        .addComponent(botao_limpar1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botao_login)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Campo_email1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Campo_senha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 172, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botao_login)
                    .addComponent(botao_limpar1))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Login", jPanel1);

        jLabel5.setText("Aniversario:");

        jLabel4.setText("Nome:");

        jLabel3.setText("Senha:");

        jLabel6.setText("E-mail:");

        botao_registro.setText("Registrar");
        botao_registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botao_registroActionPerformed(evt);
            }
        });

        botao_limpar2.setText("limpar");
        botao_limpar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botao_limpar2ActionPerformed(evt);
            }
        });

        try {
            Campo_aniversario2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        Campo_aniversario2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Campo_aniversario2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 227, Short.MAX_VALUE)
                        .addComponent(botao_limpar2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botao_registro))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Campo_email2)
                            .addComponent(Campo_nome2)
                            .addComponent(Campo_senha2)
                            .addComponent(Campo_aniversario2))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(Campo_email2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Campo_senha2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Campo_nome2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Campo_aniversario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botao_registro)
                    .addComponent(botao_limpar2))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Registrar", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botao_limpar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botao_limpar2ActionPerformed
        // TODO add your handling code here:
        String branco = "";
        Campo_email2.setText(branco);
        Campo_senha2.setText(branco);
        Campo_nome2.setText(branco);
        Campo_aniversario2.setText(branco);
        //Campo_aniversario2.setCalendar("01/01/1998");
    }//GEN-LAST:event_botao_limpar2ActionPerformed

    private void botao_limpar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botao_limpar1ActionPerformed
        // TODO add your handling code here:
        String branco = "";
        Campo_email1.setText(branco);
        Campo_senha1.setText(branco);
    }//GEN-LAST:event_botao_limpar1ActionPerformed

    private void botao_registroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botao_registroActionPerformed
        // TODO add your handling code here:
        try{
            String email = Campo_email2.getText();
            String senha = Campo_senha2.getText();
            String nome = Campo_nome2.getText();
            String aniversario = Campo_aniversario2.getText();

            Usuario_Modelo usm = new Usuario_Modelo(email, senha, nome, aniversario);
            Usuario_Controle usc = new Usuario_Controle();
            usc.criar_usuario(usm);
            
            javax.swing.JOptionPane aviso1 = new javax.swing.JOptionPane();
            aviso1.showMessageDialog(null, "Registrado");
        }catch(Exception erro){
            erro.printStackTrace();
            javax.swing.JOptionPane aviso2 = new javax.swing.JOptionPane();
            aviso2.showMessageDialog(null, "ERRO");
        }
    }//GEN-LAST:event_botao_registroActionPerformed

    private void botao_limpar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botao_limpar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_botao_limpar1MouseClicked

    private void botao_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botao_loginActionPerformed
        // TODO add your handling code here:
        String email = Campo_email1.getText();
        String senha = Campo_senha1.getText();
        /*
        try{
            
            
            ResultSet dados;
            Usuario_Controle usc = new Usuario_Controle();
            
            usc.Procurar_email(Campo_email1.getText());
            
            javax.swing.JOptionPane aviso1 = new javax.swing.JOptionPane();
            aviso1.showMessageDialog(null, "Login efetuado");
        }catch(Exception erro){
            erro.printStackTrace();
            javax.swing.JOptionPane aviso2 = new javax.swing.JOptionPane();
            aviso2.showMessageDialog(null, "e-mail ou Senha errado");
        }
        */
        
        
        if(email.equals("teste") && senha.equals("teste")){
            JOptionPane.showMessageDialog(null, "Logiin efetuado");
            
            Filmes tela_de_filmes = new Filmes();
            tela_de_filmes.setVisible(true);
            tela_de_filmes.pack();
            tela_de_filmes.setLocationRelativeTo(null);
            this.dispose();
            
        }
        else{
            JOptionPane.showMessageDialog(null, "e-mail ou senha errados");
        }
        
    }//GEN-LAST:event_botao_loginActionPerformed

    private void Campo_aniversario2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Campo_aniversario2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Campo_aniversario2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFormattedTextField Campo_aniversario2;
    private javax.swing.JTextField Campo_email1;
    private javax.swing.JTextField Campo_email2;
    private javax.swing.JTextField Campo_nome2;
    private javax.swing.JPasswordField Campo_senha1;
    private javax.swing.JTextField Campo_senha2;
    private javax.swing.JButton botao_limpar1;
    private javax.swing.JButton botao_limpar2;
    private javax.swing.JButton botao_login;
    private javax.swing.JButton botao_registro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
